package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class CricketCoach implements Coach {

    private WishService wishService;

    public CricketCoach(@Qualifier("motivateWishService") WishService wishService) {
        this.wishService = wishService;
    }

    public String getDailyWorkOut() {
        return "Spend 30 mins batting practice";
    }

    public String getWish() {
        return this.wishService.getWish();
    }
}
