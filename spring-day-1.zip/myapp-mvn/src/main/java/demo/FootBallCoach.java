package demo;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("myFootBallCoach")
//@Scope("prototype")
public class FootBallCoach implements Coach {
//    @Autowired
//    @Qualifier("happyWishService")
    private WishService wishService;

    @Value("${foo.email}")
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDailyWorkOut() {
        return "Spend 30 mins kicking practice";
    }

    @Autowired
    public void setWishService(@Qualifier("happyWishService") WishService wishService) {
        this.wishService = wishService;
    }

    @Override
    public String getWish() {
        return this.wishService.getWish();
    }

    @PostConstruct
    public void startupMethod() {
        System.out.println("started");
    }

    @PreDestroy
    public void destroyMethod() {
        System.out.println("destroyed");
    }
}
