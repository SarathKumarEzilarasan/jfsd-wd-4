package demo;

public interface Coach {
    public String getDailyWorkOut();
    public String getWish();
}
