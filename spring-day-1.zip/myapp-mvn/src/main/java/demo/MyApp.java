package demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.List;

public class MyApp {
    public static void main(String[] args) {
////        CricketCoach coach = new CricketCoach();
//        Coach coach = new CricketCoach(new HappyWishService());
//        System.out.println(coach.getDailyWorkOut());

//        ClassPathXmlApplicationContext context =
//                new ClassPathXmlApplicationContext("config.xml");
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(SportsConfig.class);
//        FootBallCoach coach1 = context.getBean("myFootBallCoach", FootBallCoach.class);
//        System.out.println(coach1.getDailyWorkOut());
//        System.out.println(coach1.getWish());
//        System.out.println(coach1.getEmail());
        List<String> list = context.getBean("list", List.class);
        System.out.println(list.size());
        context.close();
    }
}

// singleton