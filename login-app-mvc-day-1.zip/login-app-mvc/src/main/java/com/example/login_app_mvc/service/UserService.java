package com.example.login_app_mvc.service;

import com.example.login_app_mvc.dto.UserDto;
import com.example.login_app_mvc.entity.User;

import java.util.List;

public interface UserService {
    UserDto saveUser(UserDto userDto);

    UserDto findUserByEmail(String email);

    List<UserDto> findAllUsers();
}
