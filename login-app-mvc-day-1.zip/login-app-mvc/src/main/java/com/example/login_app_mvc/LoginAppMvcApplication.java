package com.example.login_app_mvc;

import com.example.login_app_mvc.dto.UserDto;
import com.example.login_app_mvc.entity.User;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class LoginAppMvcApplication {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.typeMap(UserDto.class, User.class)
                .addMapping(UserDto::getFirstName + UserDto::getLastName,User::setName)
        return modelMapper;
    }

    public static void main(String[] args) {
        SpringApplication.run(LoginAppMvcApplication.class, args);
    }

}
