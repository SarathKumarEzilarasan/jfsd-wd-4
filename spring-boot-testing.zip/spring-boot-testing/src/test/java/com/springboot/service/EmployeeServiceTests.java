package com.springboot.service;

import com.springboot.exception.ResourceNotFoundException;
import com.springboot.model.Employee;
import com.springboot.repository.EmployeeRepository;
import com.springboot.service.impl.EmployeeServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTests {
    @Mock
    private EmployeeRepository employeeRepository;
    @InjectMocks
    private EmployeeServiceImpl employeeService;


    @Test
    public void givenEmployee_whenSaveEmployee_thenReturnEmployee() {
        //given
        Employee employee1 = new Employee();
        employee1.setEmail("test@gmail.com");
        employee1.setFirstName("john");
        employee1.setLastName("doe");
        given(employeeRepository.findByEmail(employee1.getEmail()))
                .willReturn(Optional.empty());
        given(employeeRepository.save(employee1)).willReturn(employee1);
        //when
        Employee savedEmployee = employeeService.saveEmployee(employee1);
        //then
        assertThat(savedEmployee).isNotNull();
    }

    @Test
    public void givenExistingEmail_whenSaveEmployee_thenThrowsException() {
        //given
        Employee employee1 = new Employee();
        employee1.setEmail("test@gmail.com");
        employee1.setFirstName("john");
        employee1.setLastName("doe");
        given(employeeRepository.findByEmail(employee1.getEmail()))
                .willReturn(Optional.of(employee1));
        //when
        assertThrows(ResourceNotFoundException.class, () -> employeeService.saveEmployee(employee1));
        //then
        verify(employeeRepository, never()).save(any(Employee.class));
    }

    @Test
    public void givenEmployeesList_whenGetAllEmployees_thenReturnEmployeesList() {
        Employee employee1 = new Employee();
        employee1.setEmail("test@gmail.com");
        employee1.setFirstName("john");
        employee1.setLastName("doe");
        given(employeeRepository.findAll())
                .willReturn(List.of(employee1));

        List<Employee> employees = employeeService.getAllEmployees();

        assertThat(employees.size()).isEqualTo(1);
    }

    @Test
    public void givenEmployeeId_whenDeleteEmployee_thenNothing() {
        long employeeId = 1L;
        willDoNothing().given(employeeRepository).deleteById(employeeId);
        employeeService.deleteEmployee(employeeId);
        verify(employeeRepository,times(1)).deleteById(employeeId);
    }

}
