package com.springboot.repository;

import com.springboot.model.Employee;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class EmployeeRepositoryTests {
    @Autowired
    private EmployeeRepository employeeRepository;
    private Employee employee;

    @DisplayName("Test case for save employee operation")
    @Test
    public void givenEmployee_whenSave_thenReturnSavedEmployee() {
        //given
        Employee employee1 = new Employee();
        employee1.setEmail("test@gmail.com");
        employee1.setFirstName("john");
        employee1.setLastName("doe");
        //when
        Employee savedEmployee = employeeRepository.save(employee1);
        //then -> assertion
        assertThat(savedEmployee).isNotNull();
        assertThat(savedEmployee.getId()).isGreaterThan(0);
    }

    @Test
    public void givenEmployeesList_whenFindAll_thenReturnEmployeeList() {
        //given
        Employee employee1 = new Employee();
        employee1.setEmail("test@gmail.com");
        employee1.setFirstName("john");
        employee1.setLastName("doe");
        Employee employee2 = new Employee();
        employee2.setEmail("test@gmail.com");
        employee2.setFirstName("peter");
        employee2.setLastName("doe");
        employeeRepository.save(employee1);
        employeeRepository.save(employee2);
        //when
        List<Employee> employees = employeeRepository.findAll();
        //then
        assertThat(employees).isNotNull();
        assertThat(employees.size()).isEqualTo(2);
    }

}
