package com.example.spring_webflux_demo.service.impl;

import com.example.spring_webflux_demo.dto.EmployeeDto;
import com.example.spring_webflux_demo.entity.Employee;
import com.example.spring_webflux_demo.repository.EmployeeRepository;
import com.example.spring_webflux_demo.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
    private ModelMapper modelMapper;


    @Override
    public Mono<EmployeeDto> saveEmployee(EmployeeDto employeeDto) {
        Employee employee = modelMapper.map(employeeDto, Employee.class);
        return employeeRepository.save(employee)
                .map(entity -> modelMapper.map(entity, EmployeeDto.class));
    }

    @Override
    public Mono<EmployeeDto> getEmployee(String id) {
        return null;
    }

    @Override
    public Flux<EmployeeDto> getEmployees() {
        return employeeRepository.findAll()
                .map(entity -> modelMapper.map(entity, EmployeeDto.class));
    }

    @Override
    public Mono<EmployeeDto> updateEmployee(EmployeeDto employeeDto, String id) {
        return null;
    }

    @Override
    public Mono<Void> deleteEmployee(String id) {
        return null;
    }
}
