package com.example.spring_webflux_demo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public class FluxMonoGeneratorService {

    public static Mono<String> nameMono() {
        return Mono.just("john").log();
    }

    public static Flux<String> namesFlux() {
        return Flux.fromIterable(List.of("peter", "john"))
                .log()
                .map(String::toUpperCase)
                .filter(name -> name.length() > 4);
    }

    public static void main(String[] args) {
//        nameMono()
//                .subscribe(System.out::println);
        namesFlux()
                .subscribe(System.out::println);
    }
}
