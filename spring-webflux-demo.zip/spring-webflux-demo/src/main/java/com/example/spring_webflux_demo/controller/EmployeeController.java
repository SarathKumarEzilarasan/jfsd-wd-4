package com.example.spring_webflux_demo.controller;

import com.example.spring_webflux_demo.dto.EmployeeDto;
import com.example.spring_webflux_demo.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.time.Duration;
import java.util.stream.Stream;

@RestController
@AllArgsConstructor
public class EmployeeController {
    private EmployeeService employeeService;

    @PostMapping
    @ResponseStatus(value = HttpStatus.CREATED)
    public Mono<EmployeeDto> saveEmployee(@RequestBody EmployeeDto employeeDto) {
        return employeeService.saveEmployee(employeeDto);
    }

    @GetMapping
    @ResponseStatus(value = HttpStatus.OK)
    public Flux<EmployeeDto> getEmployees() {
        return employeeService.getEmployees();
    }

    //server side event
    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<EmployeeDto> streamAllUsers() {
        return employeeService
                .getEmployees()
                .flatMap(employeeDto -> Flux
                        .zip(
                                Flux.interval(Duration.ofSeconds(2)), Flux.fromStream(Stream.generate(() -> employeeDto))
                        )
                        .map(Tuple2::getT2)
                );
    }

}
