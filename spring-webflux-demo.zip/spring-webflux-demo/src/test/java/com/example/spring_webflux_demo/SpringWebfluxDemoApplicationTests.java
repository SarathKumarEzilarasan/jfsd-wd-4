package com.example.spring_webflux_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebfluxDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
