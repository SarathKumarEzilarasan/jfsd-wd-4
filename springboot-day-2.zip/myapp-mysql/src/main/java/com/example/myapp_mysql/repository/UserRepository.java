package com.example.myapp_mysql.repository;

import com.example.myapp_mysql.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long> {

}
