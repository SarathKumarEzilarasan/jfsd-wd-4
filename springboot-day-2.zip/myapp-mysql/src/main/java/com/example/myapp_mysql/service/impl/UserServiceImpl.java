package com.example.myapp_mysql.service.impl;

import com.example.myapp_mysql.dto.UserDto;
import com.example.myapp_mysql.entity.User;
import com.example.myapp_mysql.mapper.UserMapper;
import com.example.myapp_mysql.repository.UserRepository;
import com.example.myapp_mysql.service.UserService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    private ModelMapper modelMapper;

    @Override
    public UserDto createUser(UserDto userDto) {
//        User user = UserMapper.mapToUser(userDto);
        User user = modelMapper.map(userDto, User.class);
        User savedUser = userRepository.save(user);
//        UserDto returnedDto = UserMapper.mapToUserDto(savedUser);
        UserDto returnedDto = modelMapper.map(savedUser, UserDto.class);
        return returnedDto;
    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream()
                .map(UserMapper::mapToUserDto)
                .toList();
    }

    @Override
    public UserDto getUser(Long id) {
        User user = userRepository.findById(id).get();
        UserDto returnedDto = UserMapper.mapToUserDto(user);
        return returnedDto;
    }

    @Override
    public UserDto updateUser(Long id, UserDto userDto) {
        User user = UserMapper.mapToUser(userDto);

        User existingUser = userRepository.findById(id).get();
        existingUser.setFirstName(user.getFirstName());
        existingUser.setLastName(user.getLastName());
        existingUser.setEmail(user.getEmail());
        User savedUser = userRepository.save(existingUser);

        UserDto returnedDto = UserMapper.mapToUserDto(savedUser);
        return returnedDto;
    }

    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
