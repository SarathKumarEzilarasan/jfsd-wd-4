package com.example.myapp_mysql;

import com.example.myapp_mysql.dto.UserDto;
import com.example.myapp_mysql.entity.User;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MyappMysqlApplication {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
//        modelMapper.createTypeMap(UserDto.class, User.class)
//                .addMapping(UserDto::getEmail,User::setFirstName)
//                .addMapping(UserDto::getLastName,User::setFirstName)
//                .addMapping(UserDto::getEmail,User::setFirstName)
//                .addMapping(UserDto::getEmail,User::setFirstName)
//                .addMapping(UserDto::getEmail,User::setFirstName);
        return modelMapper;
    }

    public static void main(String[] args) {
        SpringApplication.run(MyappMysqlApplication.class, args);
    }

}
