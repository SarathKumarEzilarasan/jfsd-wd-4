package com.example.myapp_mysql;

public class Demo {
    public static void main(String[] args) {
        print("hello", "from");
    }

    public static void print(String input, String input1) {
        String s = String.format("%s world %s java", input);

        System.out.println(s);
    }
}
