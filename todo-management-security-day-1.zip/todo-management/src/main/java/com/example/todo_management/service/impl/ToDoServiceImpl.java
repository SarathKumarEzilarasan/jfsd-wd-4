package com.example.todo_management.service.impl;

import com.example.todo_management.dto.ToDoDto;
import com.example.todo_management.entity.ToDo;
import com.example.todo_management.repository.ToDoRepository;
import com.example.todo_management.service.ToDoService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class ToDoServiceImpl implements ToDoService {
    private ToDoRepository toDoRepository;
    private ModelMapper modelMapper;

    @Override
    public ToDoDto addToDo(ToDoDto toDoDto) {
        ToDo toDo = convertToEntity(toDoDto);
        return convertToToDoDto(toDoRepository.save(toDo));
    }

    @Override
    public ToDoDto getToDo(Long id) {
        return convertToToDoDto(toDoRepository.findById(id).get());
    }

    @Override
    public List<ToDoDto> getAllToDos() {
        return convertToListToDoDto(toDoRepository.findAll());
    }

    @Override
    public ToDoDto updateToDo(ToDoDto toDoDto, Long id) {
        ToDo toDo = toDoRepository.findById(id).get();
        toDo.setId(toDoDto.getId());
        toDo.setTitle(toDoDto.getTitle());
        toDo.setDescription(toDoDto.getDescription());
        toDo.setCompleted(toDoDto.isCompleted());

        return convertToToDoDto(toDoRepository.save(toDo));
    }

    @Override
    public void deleteToDo(Long id) {
        toDoRepository.deleteById(id);
    }

    @Override
    public ToDoDto completeTodo(Long id) {
        ToDo toDo = toDoRepository.findById(id).get();
        toDo.setCompleted(true);
        return convertToToDoDto(toDoRepository.save(toDo));
    }

    @Override
    public ToDoDto incompleteTodo(Long id) {
        ToDo toDo = toDoRepository.findById(id).get();
        toDo.setCompleted(false);
        return convertToToDoDto(toDoRepository.save(toDo));
    }

    public ToDoDto convertToToDoDto(ToDo toDo) {
        return modelMapper.map(toDo, ToDoDto.class);
    }

    public ToDo convertToEntity(ToDoDto toDoDto) {
        return modelMapper.map(toDoDto, ToDo.class);
    }

    public List<ToDoDto> convertToListToDoDto(List<ToDo> toDos) {
        return toDos.stream().map(
                toDo -> modelMapper.map(toDo, ToDoDto.class)).toList();
    }

    public List<ToDo> convertToListEntity(List<ToDoDto> toDoDtos) {
        return toDoDtos.stream().map(
                toDoDto -> modelMapper.map(toDoDto, ToDo.class)).toList();
    }
}
