package com.example.todo_management.controller;

import com.example.todo_management.dto.ToDoDto;
import com.example.todo_management.service.ToDoService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("api/todos")
public class ToDoController {
    private ToDoService toDoService;

    @PostMapping
//    @PreAuthorize("hasRole(\"ADMIN\")")
    public ResponseEntity<ToDoDto> addToDo(@RequestBody ToDoDto toDoDto) {
        return new ResponseEntity<>(toDoService.addToDo(toDoDto), HttpStatus.CREATED);
    }

    @GetMapping
//    @PreAuthorize("hasRole(\"ADMIN\")")
    public ResponseEntity<List<ToDoDto>> getAllTodos() {
        return new ResponseEntity<>(toDoService.getAllToDos(), HttpStatus.OK);
    }

    @GetMapping("{id}")
    public ResponseEntity<ToDoDto> getTodo(@PathVariable("id") Long id) {
        return new ResponseEntity<>(toDoService.getToDo(id), HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<ToDoDto> updateToDo(@RequestBody ToDoDto toDoDto, @PathVariable("id") Long id) {
        return new ResponseEntity<>(toDoService.updateToDo(toDoDto, id), HttpStatus.OK);
    }

/////////
}
