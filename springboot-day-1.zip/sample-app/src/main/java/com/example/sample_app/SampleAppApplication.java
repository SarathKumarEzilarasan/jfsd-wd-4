package com.example.sample_app;

import com.example.sample_app.bean.Student;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SampleAppApplication {

    public static void main(String[] args) {
        ApplicationContext context =
                SpringApplication.run(SampleAppApplication.class, args);
    }

}
