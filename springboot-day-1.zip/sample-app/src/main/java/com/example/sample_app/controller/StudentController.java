package com.example.sample_app.controller;

import com.example.sample_app.bean.Student;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("students")
public class StudentController {

    private List<Student> students = Arrays.asList(
            new Student(1, "John", "Doe"),
            new Student(2, "Peter", "Doe")
    );

    @GetMapping("student")
    public ResponseEntity<Student> getStudent() {
        return new ResponseEntity<>(students.get(0), HttpStatus.OK);
    }

    @GetMapping("students")
    public ResponseEntity<List<Student>> getStudents() {
        return new ResponseEntity<>(students, HttpStatus.OK);
    }

    @GetMapping("{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable("id") int studentId) {
        return new ResponseEntity<>(students.get(studentId), HttpStatus.OK);
    }

    @GetMapping("query")
    public ResponseEntity<Student> getStudentByUsingQueryParam(@RequestParam int id) {
        return new ResponseEntity<>(students.get(id), HttpStatus.OK);
    }

    @PostMapping("create")
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        return new ResponseEntity<>(student, HttpStatus.CREATED);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student, @PathVariable("id") int studentId) {
        return new ResponseEntity<>(students.get(studentId), HttpStatus.OK);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") int studentId) {
        return new ResponseEntity<>("User deleted successfully!!!", HttpStatus.NO_CONTENT);
    }

}
