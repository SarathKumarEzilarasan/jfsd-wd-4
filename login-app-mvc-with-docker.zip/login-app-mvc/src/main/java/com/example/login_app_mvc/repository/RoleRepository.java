package com.example.login_app_mvc.repository;

import com.example.login_app_mvc.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Long> {
    Role findByName(String roleAdmin);
}
