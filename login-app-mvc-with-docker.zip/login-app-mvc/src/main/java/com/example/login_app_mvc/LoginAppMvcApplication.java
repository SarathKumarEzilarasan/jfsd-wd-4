package com.example.login_app_mvc;

import com.example.login_app_mvc.dto.UserDto;
import com.example.login_app_mvc.entity.User;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class LoginAppMvcApplication {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();

        Converter<UserDto, User> dtoToEntityConverter = ctx -> {
            UserDto source = ctx.getSource();
            User destination = new User();
            destination.setId(source.getId());
            destination.setEmail(source.getEmail());
            destination.setPassword(source.getPassword());
            destination.setName(source.getFirstName() + " " + source.getLastName());
            return destination;
        };
        Converter<User, UserDto> entityToDtoConverter = ctx -> {
            User source = ctx.getSource();
            UserDto destination = new UserDto();
            destination.setId(source.getId());
            destination.setEmail(source.getEmail());
            destination.setPassword(source.getPassword());
            String name = source.getName();
            String[] names = name.split(" ");
            destination.setFirstName(names[0]);
            destination.setLastName(names.length > 1 ? names[1] : "");
            return destination;
        };


        modelMapper.addConverter(dtoToEntityConverter, UserDto.class, User.class);
        modelMapper.addConverter(entityToDtoConverter, User.class, UserDto.class);
        return modelMapper;
    }

    public static void main(String[] args) {
        SpringApplication.run(LoginAppMvcApplication.class, args);
    }

}
