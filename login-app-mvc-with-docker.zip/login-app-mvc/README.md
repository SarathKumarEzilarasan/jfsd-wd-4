git clone https://github.com/docker/scout-cli
cd login-app-mvc
mvn clean package


docker build . -t login-app-mvc
docker-compose up